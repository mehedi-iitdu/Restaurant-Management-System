$(window).on('load', function(){
    var restaurant_id = $('#scooper-widget').data('restaurant');
    var iframe = document.querySelector("#scooper-widget iframe");
    iframe.contentWindow.postMessage( restaurant_id, '*');
});




jQuery(function($){
    $(window).bind('message', function(event){
        var frame,
        oEvent = event.originalEvent;
		frame = oEvent.data;

		switch(frame.command) {
			case 'addClass':
				$('#scooper-widget').addClass(frame.addClass);
				break;
			case 'removeClass':
				$('#scooper-widget').removeClass(frame.removeClass);
				break;
			case 'both':
				$('#scooper-widget').removeClass(frame.removeClass).addClass(frame.addClass);
				break;
			case 'hasDelayRemove':
                setTimeout(function() {
				    $('#scooper-widget').removeClass(frame.removeClass);
                }, frame.duration);
				break;
		}
    });
});

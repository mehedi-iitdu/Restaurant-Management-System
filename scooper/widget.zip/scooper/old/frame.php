<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>


    <button type="button" name="button" id="bestellen_oben">fdgdfg</button>
    <script>
        if (top != self) {
            jQuery(function($) {
                if (!!window.postMessage) {
                    $('#bestellen_oben').click(function(){
                        parent.postMessage('5000', '*');
                    });
                }
            })
        }
    </script>
</body>
</html>

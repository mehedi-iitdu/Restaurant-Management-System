// $(document).ready(function(){
    window.addEventListener('message', function (e) {
        $(document.body).find('#testdiv').html( e.data );
    });
// });


function widgetOpen(booking){
    if(booking == 'booking'){
        $(document.body).addClass('widget-open');
        parent.postMessage({"command":"both", "addClass":"widget-open", "removeClass":"widget-closed"}, '*');
    }
}
function widgetClose(){
    if($(document.body).hasClass('fullw-widget')){
        $('.widget-container').delay(400).queue(function( nxt ) {
            $('.widget-container').load('booking.html', function(){
                $('.widget-container').fadeIn('slow');
            });
            nxt();
        });
    }
    if($(document.body).hasClass('widget-open')){
        $(document.body).removeClass('widget-open w-select-open fullw-widget');
        parent.postMessage({"command":"both", "addClass":"widget-closed", "removeClass":"widget-open w-select-open fullw-widget"}, '*');
        $('.options.dropdown, .booking-field.person').removeClass('opened');
    }
}
function openSelect(type) {
    if ( type == 'person' ) {
        if ($('.dropdown.person-dropdown').hasClass('opened')) {
            parent.postMessage({"command":"removeClass", "removeClass":"w-select-open"}, '*');
            $(document.body).removeClass('w-select-open');
            $('.dropdown.person-dropdown, .booking-field.person').removeClass('opened');
        }else {
            parent.postMessage({"command":"addClass", "addClass":"w-select-open"}, '*');
            $(document.body).addClass('w-select-open');
            $('.dropdown.person-dropdown, .booking-field.person').addClass('opened');
            $('.dropdown.date-dropdown, .booking-field.date').removeClass('opened');
            $('.dropdown.time-dropdown, .booking-field.time').removeClass('opened');
        }
    }else if ( type == 'date' ) {
        if ($('.dropdown.date-dropdown').hasClass('opened')) {
            parent.postMessage({"command":"removeClass", "removeClass":"w-select-open"}, '*');
            $(document.body).removeClass('w-select-open');
            $('.dropdown.date-dropdown, .booking-field.date').removeClass('opened');
        }else {
            parent.postMessage({"command":"addClass", "addClass":"w-select-open"}, '*');
            $(document.body).addClass('w-select-open');
            $('.dropdown.date-dropdown, .booking-field.date').addClass('opened');
            $('.dropdown.person-dropdown, .booking-field.person').removeClass('opened');
            $('.dropdown.time-dropdown, .booking-field.time').removeClass('opened');
        }
    }else if ( type == 'time' ) {
        if ($('.dropdown.time-dropdown').hasClass('opened')) {
            parent.postMessage({"command":"removeClass", "removeClass":"w-select-open"}, '*');
            $(document.body).removeClass('w-select-open');
            $('.dropdown.time-dropdown, .booking-field.time').removeClass('opened');
        }else {
            parent.postMessage({"command":"addClass", "addClass":"w-select-open"}, '*');
            $(document.body).addClass('w-select-open');
            $('.dropdown.time-dropdown, .booking-field.time').addClass('opened');
            $('.dropdown.person-dropdown, .booking-field.person').removeClass('opened');
            $('.dropdown.date-dropdown, .booking-field.date').removeClass('opened');
        }
    }
}

function personSelect(el){

    var PersonInputNum = $(el).children('span').text();

    $('.person-select.select').find('.selected-value').children('span').html( PersonInputNum + ' people');
    parent.postMessage({"command":"removeClass", "removeClass":"w-select-open"}, '*');
    $(document.body).removeClass('w-select-open');
    $('.dropdown.person-dropdown, .booking-field.person').removeClass('opened');

    if( $(el).hasClass('selected') ){
        return;
    }else {
        $(el).parent().find('.persons-option.selected').removeClass('selected');
        $(el).addClass('selected');
    }
}

function timeSelect(el){

    var TimeInputTimePart = $(el).children('.time-time').text();
    var TimeInputDayPart = $(el).children('.day-part').text();
    var TimeInputArea = $(el).children('.area-name').text();

    $('.time-select.select').find('.selected-value').html( TimeInputTimePart + TimeInputDayPart + '<span class="area-filter">' + TimeInputArea + '</span>');
    parent.postMessage({"command":"removeClass", "removeClass":"w-select-open"}, '*');
    $(document.body).removeClass('w-select-open');
    $('.dropdown.time-dropdown, .booking-field.time').removeClass('opened');

    if( $(el).hasClass('selected') ){
        return;
    }else {
        $(el).parent().find('.time-option.selected').removeClass('selected');
        $(el).addClass('selected');
    }
}

function datepickOpen(){
    $( "#datepicker" ).datepicker({
        altField: "#dateAlter",
        altFormat: "MM d",
        defaultDate: 0,
        minDate: 0,
        firstDay: 1,
        dayNamesMin: [ "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" ],
        onSelect: function(selectedDate, inst){

            var suffix = "";
            switch(inst.selectedDay) {
                case '1': case '21': case '31': suffix = 'st'; break;
                case '2': case '22': suffix = 'nd'; break;
                case '3': case '23': suffix = 'rd'; break;
                default: suffix = 'th';
            }

            var SelectOutput = "";
            var outputDayName = $.datepicker.formatDate("DD", $(this).datepicker("getDate"));
            var today = new Date();
            var day1 = today.getDate().toString();
            var day2 = (new Date(today.getTime() + 24 * 60 * 60 * 1000).getDate()).toString();
            var day3 = (new Date(today.getTime() + 2 * (24 * 60 * 60 * 1000)).getDate()).toString();
            var day4 = (new Date(today.getTime() + 3 * (24 * 60 * 60 * 1000)).getDate()).toString();
            var day5 = (new Date(today.getTime() + 4 * (24 * 60 * 60 * 1000)).getDate()).toString();
            var day6 = (new Date(today.getTime() + 5 * (24 * 60 * 60 * 1000)).getDate()).toString();
            var day7 = (new Date(today.getTime() + 6 * (24 * 60 * 60 * 1000)).getDate()).toString();

            switch(inst.selectedDay) {
                case day1: SelectOutput = 'today'; break;
                case day2: SelectOutput = 'tomorrow'; break;
                case day3 : case day4 : case day5 : case day6 : case day7 : SelectOutput = 'next ' + outputDayName; break;
                default: SelectOutput = $("#dateAlter").val() + suffix;
            }

            $(".date-select.select .selected-value").html(SelectOutput);


            parent.postMessage({"command":"removeClass", "removeClass":"w-select-open"}, '*');
            $(document.body).removeClass('w-select-open');
            $('.dropdown.date-dropdown, .booking-field.date').removeClass('opened');
        },
    }).datepicker("setDate", new Date());
}

$(document).on("click", function() {
    datepickOpen();
});
// $(document).addEventListener("change", function() {
//     datepickOpen();
// });





function bookDirect(){
    parent.postMessage({"command":"addClass", "addClass":"fullw-widget"}, '*');
    $(document.body).addClass('fullw-widget');
    $(".widget-container").removeClass('booking').addClass('checkout');

    $('.widget-container').fadeOut(300, function(){
        $('.widget-container').delay(400).queue(function( nxt ) {
            $(this).load('checkout.html', function(){
                $('.widget-container').fadeIn(400);
            });
            nxt();
        });
    });
}
function backToBooking(){
    parent.postMessage({"command":"hasDelayRemove", "removeClass":"fullw-widget", "duration":300}, '*');
    $(document.body).removeClass('fullw-widget');
    $(".widget-container").removeClass('checkout').addClass('booking');

    $('.widget-container').fadeOut(100, function(){
        $('.widget-container').delay(400).queue(function( nxt ) {
            $(this).load('booking.html', function(){
                $('.widget-container').fadeIn('slow');
            });
            nxt();
        });
    });



}
function checkout(){
    $('.widget-container').fadeOut(400, function(){
        $(this).load('processing.html', function(){
            $('.widget-container').fadeIn(400);
        });
    });
    $('.widget-container').delay(800).queue(function( nghfgxt ) {
        $(this).load('confirm.html', function(){
            $('.widget-container').fadeIn(400);
        });
        nghfgxt();
    });
}

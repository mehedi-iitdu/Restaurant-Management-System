<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>


    <div id="autoIframe">
        <iframe src="http://creativeitem.com/project/adnancorp/frame.php" width="" height=""></iframe>
    </div>
    <script type="text/javascript">
        jQuery(function($){
            $(window).bind('message', function(event){
                var height,
                oEvent = event.originalEvent;
                // if (oEvent.origin != window.location.origin) {        // compare against window.location.origin
                //     return false;
                // } else {
                    // height = parseInt(oEvent.data);
                    height = oEvent.data;
                    console.log(height);                  // make sure to assign height
                    $('#autoIframe').addClass(height);
                // }
            });
        });
    </script>
</body>
</html>

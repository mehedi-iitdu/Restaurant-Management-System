<?php if($timeConfig->opening_time != 'Closed' || $timeConfig->closing_time != 'Closed'): ?>
    <?php
        $i = 0;
    ?>
    <?php for($time = strtotime($timeConfig->opening_time); $time <= strtotime($timeConfig->closing_time); $time = strtotime('+15 minutes', $time)): ?>
            <option value="<?php echo e(date("H:i:s", $time)); ?>"><?php echo e(date("H:i:s", $time)); ?></option>
        <?php
            $i++;
        ?>
    <?php endfor; ?>
<?php endif; ?>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppReview extends Model
{
    //
}

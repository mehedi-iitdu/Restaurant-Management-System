<div class="finish-close">
    <div class="back">
        <a onclick="widgetClose()">
            <svg class="close">
                <path d="M6.7,5.2l3.5-3.5c0.4-0.4,0.4-1,0-1.4c-0.4-0.4-1-0.4-1.4,0L5.2,3.8L1.7,0.3c-0.4-0.4-1-0.4-1.4,0
        c-0.4,0.4-0.4,1,0,1.4l3.5,3.5L0.3,8.8c-0.4,0.4-0.4,1,0,1.4c0.4,0.4,1,0.4,1.4,0l3.5-3.5l3.5,3.5c0.4,0.4,1,0.4,1.4,0
        c0.4-0.4,0.4-1,0-1.4L6.7,5.2z"></path>
            </svg>
        </a>
    </div>
</div>
<div class="finish-screen finish-loading-screen">
    <div class="finish-wrapper">
        <div class="finish-header">
            <div class="status-title">
                <h2>We are processing your reservation!</h2>
                <p>
                    This page will update in a few seconds...
                </p>
            </div>
        </div>
    </div>
</div>
